# eccoseas
Python tools to generate regional model grids from ECCO State Estimates
