toolbox
=======

.. autosummary::
   :toctree: generated

The toolbox of the eccoseas package has several helpful modules.

Key Modules
-----------

reprojection
^^^^^^^^^^^^
This function is designed to compute reprojects fields and grids from one coordinate system to another.


