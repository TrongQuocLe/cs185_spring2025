downscale
=========

This page describes the modules available in the downscale package.

Key Functions
-------------

horizonal
^^^^^^^^^
This function is designed to complete horizonal interpolation.



